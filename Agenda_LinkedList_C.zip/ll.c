#include <stdio.h>
#include <string.h>
#include "list.h"

int main()
{
	list LL;
    CommandListener(&LL);
}

